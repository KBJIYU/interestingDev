#  Jiyu's note of learning algorithm with Python

## Intro
- Jiyu's learning note of `Data Structure` and `Algoritms`.
- Inspired by book `圖說演算法-使用Python`.

## Contents
- TBD.
