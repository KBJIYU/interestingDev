from .hash_table import HashTable

class QuadraticProbing(HashTable):

    def __init__(self):
        super(self.__class__, self).__init__()
