This is a utility folder to store images and other resources used in notebooks.
